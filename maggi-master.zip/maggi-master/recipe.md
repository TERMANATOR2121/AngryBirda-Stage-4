first, 
Boil 1 & 1/2 cups water in a pan and add Maggi Noodles Simmer for two minutes till the Maggi is fully boiled.when it is fully boiled turn it off .

then,
 in anothere pan take 1 teaSpoon oil , and fry chropped onion and carrot and peas and add salt as per your choice.

when onion and carrot turns reddish then add that tastemaker in it .

and when the tastemaker is finally mixed properly with onions and other vegetables add that fully boiled maggi noodles in it.

keep it for 2 min and then serve the maggi in bowl with spoon and fork. 
and ENJOY YOUR MEAL :)