the ingredients of maggie (for 2) are:-
1)2 cup water
2)1 packet of maggie 
   there 2 maggie parts will be there and 1 tastemaker

3)green vegetables like 
   carrot
   onion
   peas

4)1 teaspoon oil